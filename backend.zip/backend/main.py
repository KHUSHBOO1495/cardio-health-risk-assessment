import os
import joblib
import numpy as np
from fastapi import FastAPI
from pydantic import BaseModel

app = FastAPI()

from fastapi.middleware.cors import CORSMiddleware

app.add_middleware(
    CORSMiddleware,
    allow_origins=[
        "http://localhost:3000",
        "http://127.0.0.1:3000"
    ],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

BASE_DIR = os.path.dirname(os.path.abspath(__file__))

model = joblib.load(
    os.path.join(BASE_DIR, "saved_models", "best_model.pkl")
)
scaler = joblib.load(
    os.path.join(BASE_DIR, "saved_models", "scaler.pkl")
)

class PatientData(BaseModel):
    features: list

@app.get("/model-metrics")
def model_metrics():
    return {
        "Logistic Regression": 0.720,
        "KNN": 0.651,
        "Decision Tree": 0.733,
        "Random Forest": 0.714,
        "best_model": "Decision Tree"
    }

@app.post("/predict")
def predict(data: PatientData):
    X = np.array([data.features])
    X_scaled = scaler.transform(X)
    pred = model.predict(X)
    return {"prediction": int(pred[0])}
